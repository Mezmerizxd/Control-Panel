<?php
header("Location: authenticate.php");
?>
