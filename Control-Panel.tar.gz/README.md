# Control-Panel
Small project I'm working on.

# Setup
1. Import "accounts.sql" into your MariaDB.
2. Put all the files from "Control-Panel" into your http root directory.

# Feedback
I would really appreciate feedback and tips as I could be doing a lot wrong.
